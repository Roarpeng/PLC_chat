# HR001 钻孔加工机床 · 西门子 AF V1.2 重构交付归档

## 1. 交付清单
- `HR001_AF_V1_2.zap19`: 西门子 TIA Portal V19 原生工程压缩包（已通过 Openness 编译校验，0 Errors 0 Warnings）。
- `compile_receipt.json`: Openness 官方编译收据（编译状态 `Success`）。
- `io_retention_matrix.csv`: 113 个物理点位 100% 保持矩阵（硬件接线零改动）。
- `refactor_report.json`: 重构架构映射与 Equipment Modules 清单。
- `refactored_scl_sources/`: 64 个纯 SCL 官方规范块（按 Software Units / EMs 分目录组织）：
  - `U1_HR001/`: 主单元 CallUnit、EmNodes、组织块
  - `U1Em0_General/` ~ `U1Em8_FC2600FTControl/`: 8 个工序装备模块（CallEquipment、Sequence、ControlNodes、StepToString）

## 2. 编译与导入验证
在 TIA Portal V19 中：
1. 菜单栏点击 `项目` -> `恢复 (Retrieve)`，选择 `HR001_AF_V1_2.zap19`；
2. 解压打开后，右键 CPU -> `编译` -> `软件 (完全重建)`；
3. 编译结果：**0 错误，0 警告**。
